package com.example.miwok;

public class Word {
    private String mDefaultTranslation;
    private String mKannadaTranslation;
    private int mImageResourceId = NO_IMAGE_PROVIDED;
    private static final int NO_IMAGE_PROVIDED = -1;
    private int mAudioResourceId;

    public Word(String defaultTranslation, String kannadaTranslation){
        mDefaultTranslation = defaultTranslation;
        mKannadaTranslation = kannadaTranslation;
    }

    public Word(String defaultTranslation, String kannadaTranslation, int imageResourceId){
        mDefaultTranslation = defaultTranslation;
        mKannadaTranslation = kannadaTranslation;
        mImageResourceId = imageResourceId;
    }

    public Word(String defaultTranslation, String kannadaTranslation, int imageResourceId, int audioResourceId){
        mDefaultTranslation = defaultTranslation;
        mKannadaTranslation = kannadaTranslation;
        mImageResourceId = imageResourceId;
        mAudioResourceId = audioResourceId;
    }

    public String getDefaultTranslation(){
        return mDefaultTranslation;
    }

    public String getKannadaTranslation(){
        return  mKannadaTranslation;
    }

    public int getImageResourceId(){
        return mImageResourceId;
    }

    public boolean hasImage(){
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }

    public  int getAudioResourceId(){
        return mAudioResourceId;
    }
}
