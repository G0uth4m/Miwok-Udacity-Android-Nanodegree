package com.example.miwok;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class phrasesActivity extends AppCompatActivity {

    private MediaPlayer mMediaPlayer;

    private MediaPlayer.OnCompletionListener mCompletionListener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            releasePlayer();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        final ArrayList<Word> words = new ArrayList<Word>();

        words.add(new Word("How are you?", "Neevu hegiddira?", -1, R.raw.kannada_how_are_you));
        words.add(new Word("I'm good, thanks", "Naanu chennagiddene, dhanyavadagalu", -1, R.raw.kannada_im_good_thank_you));
        words.add(new Word("Happy Birthday!", "Huttu habbada shubhashayagalu!", -1, R.raw.kannada_happy_birthday));
        words.add(new Word("Happy New Year!", "Hosa varshada shubhashayagalu!", -1, R.raw.kannada_happy_new_year));
        words.add(new Word("Where do you live?", "Neevu yelli vaasisuviri?", -1, R.raw.kannada_where_do_you_live));
        words.add(new Word("I live in the US", "Nanu Americadalli vaasisuttene",-1, R.raw.kannada_i_live_in_the_us));
        words.add(new Word("What fo you do for a living?", "Nimma udyoga yenu?", -1, R.raw.kannada_what_do_you_do_for_a_living));
        words.add(new Word("Is this seat taken?", "Ee aasana meesalagideye?", -1, R.raw.kannada_is_this_seat_taken));
        words.add(new Word("I have a reservation", "Nanna hattira meesalati ide", -1, R.raw.kannada_i_have_a_reservation));
        words.add(new Word("I'm a student", "Nanu vidyarti", -1, R.raw.kannada_im_a_student));
        words.add(new Word("I'm a vegetarian", "Nanu sasyahari", -1, R.raw.kannada_im_vegetarian));
        words.add(new Word("Where are you from?", "Neevu yava oorinavaru?", -1, R.raw.kannada_where_are_you_from));

        WordAdapter itemsAdapter = new WordAdapter(this, words, R.color.phrasesColor);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(itemsAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Word word = words.get(position);
                releasePlayer();
                mMediaPlayer = MediaPlayer.create(phrasesActivity.this, word.getAudioResourceId());
                mMediaPlayer.start();
                mMediaPlayer.setOnCompletionListener(mCompletionListener);

            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        releasePlayer();
    }

    public void releasePlayer(){
        if(mMediaPlayer != null){
            mMediaPlayer.release();
            mMediaPlayer = null;
        }
    }
}
