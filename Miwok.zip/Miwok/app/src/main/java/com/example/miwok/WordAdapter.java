package com.example.miwok;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class WordAdapter extends ArrayAdapter<Word> {

    private int mBackgroundColorResourceId;

    public WordAdapter(Activity context, ArrayList<Word> words, int backgroundColorResourceId){
        super(context, 0, words);
        mBackgroundColorResourceId = backgroundColorResourceId;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;

        if(listItemView == null){
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        Word currentWord = getItem(position);

        TextView kannadaText = (TextView) listItemView.findViewById(R.id.kannadaText);
        kannadaText.setText(currentWord.getKannadaTranslation());

        TextView defaultText = (TextView) listItemView.findViewById(R.id.defaultText);
        defaultText.setText(currentWord.getDefaultTranslation());

        ImageView img = (ImageView) listItemView.findViewById(R.id.image);

        if(currentWord.hasImage()) {
            img.setImageResource(currentWord.getImageResourceId());
            img.setVisibility(View.VISIBLE);
        }

        else{
            img.setVisibility(View.GONE);
        }

        View textContainer = listItemView.findViewById(R.id.translations_view);
        int color = ContextCompat.getColor(getContext(), mBackgroundColorResourceId);
        textContainer.setBackgroundColor(color);

        return listItemView;
    }
}
