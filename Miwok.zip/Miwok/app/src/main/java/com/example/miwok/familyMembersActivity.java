package com.example.miwok;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class familyMembersActivity extends AppCompatActivity {

    private MediaPlayer mMediaPlayer;

    private MediaPlayer.OnCompletionListener mCompletionListener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            releasePlayer();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        final ArrayList<Word> words = new ArrayList<Word>();

        words.add(new Word("mother", "thayi", R.drawable.family_mother, R.raw.kannada_mother));
        words.add(new Word("father", "thandhe", R.drawable.family_father, R.raw.kannada_father));
        words.add(new Word("brother", "sahodara", R.drawable.family_older_brother, R.raw.kannada_brother));
        words.add(new Word("sister", "sahodari", R.drawable.family_older_sister, R.raw.kannada_sister));
        words.add(new Word("grandfather", "thatha", R.drawable.family_grandfather, R.raw.kannada_grandfather));
        words.add(new Word("grandmother", "ajji", R.drawable.family_grandmother, R.raw.kannada_grandmother));
        words.add(new Word("son", "maga", R.drawable.family_son,R.raw.kannada_son));
        words.add(new Word("daughter", "magalu", R.drawable.family_daughter, R.raw.kannada_daughter));
        words.add(new Word("aunt", "chikkamma / doddamma", R.drawable.family_mother, R.raw.kannada_aunt));
        words.add(new Word("uncle", "chikkappa / doddappa", R.drawable.family_father, R.raw.kannada_uncle));

        WordAdapter  itemsAdapter = new WordAdapter(this, words, R.color.familyMenbersColor);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(itemsAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Word word = words.get(position);
                releasePlayer();
                mMediaPlayer = MediaPlayer.create(familyMembersActivity.this, word.getAudioResourceId());
                mMediaPlayer.start();
                mMediaPlayer.setOnCompletionListener(mCompletionListener);
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        releasePlayer();
    }

    public void releasePlayer(){
        if(mMediaPlayer != null){
            mMediaPlayer.release();
            mMediaPlayer = null;
        }
    }
}
