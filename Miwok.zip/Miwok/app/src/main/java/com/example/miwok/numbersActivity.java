package com.example.miwok;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class numbersActivity extends AppCompatActivity {

//    TextToSpeech t1;

    private MediaPlayer mMediaPlayer;

    private MediaPlayer.OnCompletionListener mCompletionListener = new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mp) {
            releasePlayer();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        final ArrayList<Word> words = new ArrayList<Word>();

        words.add(new Word("one", "ondhu", R.drawable.number_one, R.raw.kannada_one));
        words.add(new Word("two", "eradu", R.drawable.number_two, R.raw.kannada_two));
        words.add(new Word("three", "mooru", R.drawable.number_three, R.raw. kannada_three));
        words.add(new Word("four", "naalku", R.drawable.number_four, R.raw.kannada_four));
        words.add(new Word("five", "eidu", R.drawable.number_five, R.raw.kannada_five));
        words.add(new Word("six", "aaru", R.drawable.number_six, R.raw.kannada_six));
        words.add(new Word("seven", "elu", R.drawable.number_seven, R.raw.kannada_seven));
        words.add(new Word("eight", "entu", R.drawable.number_eight, R.raw.kannada_eight));
        words.add(new Word("nine", "ombatthu", R.drawable.number_nine, R.raw.kannada_nine));
        words.add(new Word("ten", "hatthu", R.drawable.number_ten, R.raw.kannada_ten));

        WordAdapter  itemsAdapter = new WordAdapter(this, words, R.color.numbersColor);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(itemsAdapter);

//        t1 = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
//            @Override
//            public void onInit(int status) {
//                if(status != TextToSpeech.ERROR){
//                    t1.setLanguage(Locale.ENGLISH);
//                }
//            }
//        });
//
//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                String toSpeak = "The below example demonstrates the use of TextToSpeech class. It creates a basic application that allows you to set write text and speak it";
//                t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
//            }
//        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Word word = words.get(position);
                releasePlayer();
                mMediaPlayer = MediaPlayer.create(numbersActivity.this, word.getAudioResourceId());
                mMediaPlayer.start();
                mMediaPlayer.setOnCompletionListener(mCompletionListener);
            }
        });

    }

    @Override
    protected void onStop() {
        super.onStop();
        releasePlayer();
    }

    public void releasePlayer(){
        if(mMediaPlayer != null){
            mMediaPlayer.release();
            mMediaPlayer = null;
        }
    }
}
