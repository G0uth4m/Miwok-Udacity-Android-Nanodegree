package com.example.miwok;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class colorsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.word_list);

        ArrayList<Word> words = new ArrayList<Word>();

        words.add(new Word("green", "hasiru", R.drawable.color_green));
        words.add(new Word("red", "kempu", R.drawable.color_red));
        //words.add(new Word("blue", "neeli"));
        words.add(new Word("white", "bili", R.drawable.color_white));
        words.add(new Word("black", "kappu", R.drawable.color_black));
       // words.add(new Word("orange", "kittale / kesari"));
        words.add(new Word("yellow", "haladi", R.drawable.color_mustard_yellow));
        //words.add(new Word("purple", "nerale"));
        words.add(new Word("brown", "kandu", R.drawable.color_brown));
        words.add(new Word("gray", "boodu", R.drawable.color_gray));
        //words.add(new Word("pink", "gulabi"));

        WordAdapter  itemsAdapter = new WordAdapter(this, words, R.color.colorsColor);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(itemsAdapter);
    }
}
